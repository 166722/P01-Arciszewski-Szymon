#include <iostream>
#include <fstream>

using namespace std;

void sort(double* L, int n){
	for(int i = 0; i < n - 1; i++){
		int min = i; // do ustawienia liczb rosnaco
		for(int j = i + 1; j < n; j++){
			if(L[j] < L[min]){
				min = j; // szukamy elementu mniejszego od pierwszego i
			}
		}
		double t = L[i];
		L[i] = L[min];
		L[min] = t; // zapisujemy indeks j w zmiennej min
	}
}

int main () {
    ofstream sortuj("wybor.txt");
	int n;
	cout << "Wprowadz ilosc liczb w tablicy: " << endl;
	cin >> n;
	cout << endl << "Wprowadz liczby: " << endl;
	double* L = new double[n];
	for(int i = 0; i < n; i++)
		cin >> L[i];
	sort(L, n);
	sortuj << "Po sortowaniu: ";
	for(int i = 0; i < n; i++)
		sortuj << L[i] << " ";
	delete[] L;
	sortuj.close();
	system("pause");
	return 0;
}
