#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>

using namespace std;

void kubelkowe(vector<unsigned int> &lista, int k) {
	vector<vector<unsigned int>> kubelki; // lista kubelkow
	for(int i = 0; i < k; i++)
		kubelki.push_back(vector<unsigned int>()); // dodanie do listy k kubelkow
	unsigned int  max = lista[0];
	for(int i = 0; i < lista.size(); i++){
		if(lista[i] > max){
			max= lista[i]; // wyszukiwanie najwiekszego elementu na liscie
		}
	}
	max++; // zwiekszamy maxa, zeby zapobiec trafieniu maxa do kubelka k ktory nie istnieje
	for(int i = 0; i < lista.size(); i++)
		kubelki[double(lista[i])/double(max)*k].push_back(lista[i]); // wrzucamy elementy do odpowiednich kubelkow
	for(int i = 0; i < k; i++)
		sort(kubelki[i].begin(), kubelki[i].end()); // sortujemy kazdy kubelek osobno
	lista.clear(); // usuwamy elementy "lista"
	for(int i = 0; i < k; i++)
		for(int j = 0; j < kubelki[i].size(); j++)
			lista.push_back(kubelki[i][j]); // dodajemy kolejne elementy z kolejnych kubelkow na miejsce elementow "lista
}


int main () { // testy
    ofstream kubelki("kubelki.txt");
	int n, k, t;
	cout << "Podaj liczbe elementow: ";
	cin >> n;
	cout << "Podaj liczbe kubelkow: ";
	cin >> k;
	vector< unsigned int > lista;
	cout << endl << "Wprowadz elementy listy: " << endl;
	for(int i = 0; i < n; i++){
		cin >> t;
		lista.push_back(t);
	}
	kubelkowe(lista, k);
	kubelki << "Po sortowaniu: ";
	for(int i = 0; i < n; i++)
		kubelki << lista[i] << " ";
	system("pause");
	return 0;
}
