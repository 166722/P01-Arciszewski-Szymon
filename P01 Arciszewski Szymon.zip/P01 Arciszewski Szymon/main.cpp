#include <iostream>
#include <time.h>
#include <iomanip>
#include <fstream>

using namespace std;

const int N = 5000; // ustalenie liczby elementow naszej tablicy, moze byc dowolna naturalna wieksza od 2

int main()
{
    ofstream liczenie("licz.txt"); // zapisuje caly program do pliku txt

    int licz[N], tab[N], i; // definiowanie zmiennych - liczb calkowitych
	srand((unsigned)time(NULL)); // wczytanie czasu w sekundach od 1.1.1970r. z systemu do generowania liczb pseudolosowych w tablicy

	for(i=0; i<N; i++) tab[i]=(rand()%(N-1))+1; // tworzenie tablicy z pseudolosowymi liczbami od 1 do N


	for(i=0; i<N; i++)

    liczenie << setw (4)  << tab[i]; // wyswietlenie tablicy
    liczenie << endl << endl << endl;


    for(i=0; i<N; i++) licz[i] = 0; // zaczyna zliczac ilosc powtorek od 0
    for(i=0; i<N; i++)
    {
		licz[tab[i]]++; // liczenie ilosci powtorek
	}

	liczenie << "Liczby powtarzajace sie:" << endl;
    for(i=0; i<N; i++)
	{
		if(licz[i]>1)
        liczenie << i << " - powtarza sie " << licz[i] << " razy" << endl;

	}
liczenie.close(); // konczy dzialanie w pliku txt
return 0; // zwraca 0 i konczy dzialanie programu
}
